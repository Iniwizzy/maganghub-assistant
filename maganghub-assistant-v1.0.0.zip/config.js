// Pengaturan yang diisi pengembang sebelum extension dibagikan.
export const CONFIG = {
  // URL Web App Apps Script (Deploy > Web app), berakhiran /exec.
  // Kosongkan untuk mematikan fitur pengingat WhatsApp.
  SERVER_URL: 'https://script.google.com/macros/s/AKfycbxAWKs0sjiFAL4atwmuKfHf1KgiOPyplGoEfVtnBrTnen7JtFloSUxN4flhgJOt1i_v5A/exec',

  // Tautan kebijakan privasi yang sudah dihosting (wajib untuk Chrome Web Store dan Edge Add-ons).
  // Kosongkan untuk menyembunyikan tautannya di popup.
  PRIVACY_URL:
    'https://script.google.com/macros/s/AKfycbxAWKs0sjiFAL4atwmuKfHf1KgiOPyplGoEfVtnBrTnen7JtFloSUxN4flhgJOt1i_v5A/exec?page=privacy',

  SITE_ORIGIN: 'https://monev.maganghub.kemnaker.go.id',
  DASHBOARD_URL: 'https://monev.maganghub.kemnaker.go.id/dashboard',

  // Halaman form laporan harian: /dashboard/riwayat?date=YYYY-MM-DD&view=edit
  FORM_PATH: '/dashboard/riwayat',

  DEFAULT_TIMES: ['11:30', '13:30', '16:30'],
  MAX_CUSTOM_TIMES: 3,
  MIN_CHARS: 100,
  DEFAULT_MODEL: 'gemini-flash-latest',
};

/** URL langsung ke form laporan untuk tanggal "YYYY-MM-DD". */
export function formUrl(dateKey) {
  return CONFIG.SITE_ORIGIN + CONFIG.FORM_PATH + '?date=' + encodeURIComponent(dateKey) + '&view=edit';
}
