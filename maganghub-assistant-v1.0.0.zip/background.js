import { CONFIG, formUrl } from './config.js';
import { getAll, set } from './lib/storage.js';
import { activeTimes, nextOccurrence, todayKey, dayIndex, tzAbbr, timeZoneId } from './lib/schedule.js';
import { generateReport, testKey } from './lib/gemini.js';
import { callServer, serverEnabled } from './lib/server.js';

const REMIND_PREFIX = 'remind|';
const SYNC_ALARM = 'sync-server';
const WA_POLL_ALARM = 'wa-poll';
const WA_POLL_LIMIT_MS = 10 * 60 * 1000;
const LATE_LIMIT_MS = 60 * 60 * 1000; // lewati pengingat yang terlambat > 1 jam (mis. laptop baru bangun)
const NOTIF_REMIND = 'mh-remind';
const NOTIF_INFO = 'mh-info';
const SCHEDULE_KEYS = ['defaultTimes', 'customTimes', 'days', 'notifOn'];

/* ---------------- siklus hidup ---------------- */

chrome.runtime.onInstalled.addListener(() => {
  rescheduleAlarms();
});
chrome.runtime.onStartup.addListener(() => {
  rescheduleAlarms();
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if (SCHEDULE_KEYS.some((k) => k in changes)) rescheduleAlarms();
  if (SCHEDULE_KEYS.concat(['waOn']).some((k) => k in changes)) queueSync();
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === SYNC_ALARM) return void syncSettings();
  if (alarm.name === WA_POLL_ALARM) return void pollWaLink();
  if (alarm.name.startsWith(REMIND_PREFIX)) {
    handleReminder(alarm.name.slice(REMIND_PREFIX.length), alarm.scheduledTime);
  }
});

/* ---------------- pengingat notifikasi browser ---------------- */

async function rescheduleAlarms() {
  const s = await getAll();
  const existing = await chrome.alarms.getAll();
  await Promise.all(existing.filter((a) => a.name.startsWith(REMIND_PREFIX)).map((a) => chrome.alarms.clear(a.name)));
  if (!s.notifOn) return;
  for (const t of activeTimes(s.defaultTimes, s.customTimes)) {
    await chrome.alarms.create(REMIND_PREFIX + t, { when: nextOccurrence(t), periodInMinutes: 24 * 60 });
  }
}

async function handleReminder(time, scheduledTime) {
  if (scheduledTime && Date.now() - scheduledTime > LATE_LIMIT_MS) return;
  const s = await getAll();
  if (!s.notifOn) return;
  const now = new Date();
  if (!s.days[dayIndex(now)]) return;
  const today = todayKey(now);
  if (s.doneDate === today) return;
  if (await doneOnServer(s, today)) return;

  const times = activeTimes(s.defaultTimes, s.customTimes);
  const index = Math.max(1, times.indexOf(time) + 1);
  await chrome.notifications.clear(NOTIF_REMIND);
  chrome.notifications.create(NOTIF_REMIND, {
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title: 'Waktunya isi laporan MagangHub',
    message: 'Laporan hari ini belum diisi. Pengingat ke-' + index + ' dari ' + times.length + ' (' + time + ' ' + tzAbbr() + ').',
    buttons: [{ title: 'Buka form laporan' }, { title: 'Sudah absen hari ini' }],
    requireInteraction: true,
    priority: 2,
  });
}

/** Cek apakah pengguna sudah membalas "sudah" lewat WhatsApp. */
async function doneOnServer(s, today) {
  if (!linkedToServer(s)) return false;
  try {
    const st = await callServer('status', { token: s.serverToken });
    if (st.doneDate === today) {
      await set({ doneDate: today });
      return true;
    }
  } catch (e) {
    console.warn('Status server tidak terbaca:', e.message);
  }
  return false;
}

chrome.notifications.onButtonClicked.addListener((id, index) => {
  if (id !== NOTIF_REMIND) return;
  if (index === 0) openDashboard();
  else markDone(true);
  chrome.notifications.clear(id);
});

chrome.notifications.onClicked.addListener((id) => {
  if (id === NOTIF_REMIND) openDashboard();
  chrome.notifications.clear(id);
});

function openDashboard() {
  chrome.tabs.create({ url: formUrl(todayKey()) });
}

function info(title, message) {
  chrome.notifications.create(NOTIF_INFO, { type: 'basic', iconUrl: 'icons/icon128.png', title, message, priority: 0 });
}

async function markDone(done) {
  const today = todayKey();
  await set({ doneDate: done ? today : '' });
  if (done) chrome.notifications.clear(NOTIF_REMIND);
  const s = await getAll();
  if (!linkedToServer(s)) return;
  try {
    await callServer(done ? 'done' : 'undone', { token: s.serverToken, date: today });
  } catch (e) {
    console.warn('Status absen gagal dikirim ke server:', e.message);
  }
}

/* ---------------- server WhatsApp ---------------- */

function linkedToServer(s) {
  return serverEnabled() && Boolean(s.serverToken) && s.waLink === 'terhubung';
}

function queueSync() {
  // Alarm dipakai sebagai debounce; service worker bisa mati sebelum setTimeout berjalan.
  chrome.alarms.create(SYNC_ALARM, { when: Date.now() + 2000 });
}

async function syncSettings() {
  const s = await getAll();
  if (!linkedToServer(s)) return;
  try {
    await callServer('sync', {
      token: s.serverToken,
      times: activeTimes(s.defaultTimes, s.customTimes),
      days: s.days,
      waOn: s.waOn,
      tz: timeZoneId(),
    });
  } catch (e) {
    if (e.code === 'UNKNOWN_TOKEN') await resetWa();
    else console.warn('Sinkron jadwal gagal:', e.message);
  }
}

async function resetWa() {
  await set({ serverToken: '', waLink: 'belum', waPhone: '', waCode: '', waPairAt: 0 });
  chrome.alarms.clear(WA_POLL_ALARM);
}

async function checkWaLink({ notify = false } = {}) {
  const s = await getAll();
  if (!serverEnabled() || !s.serverToken) return { linked: false };
  let st;
  try {
    st = await callServer('status', { token: s.serverToken });
  } catch (e) {
    if (e.code === 'UNKNOWN_TOKEN') await resetWa();
    throw e;
  }
  if (st.linked && s.waLink !== 'terhubung') {
    await set({ waLink: 'terhubung', waPhone: st.phoneMasked || '', waCode: '', waOn: true });
    chrome.alarms.clear(WA_POLL_ALARM);
    await syncSettings();
    if (notify) info('WhatsApp terhubung', 'Pengingat laporan harian akan dikirim ke ' + (st.phoneMasked || 'nomormu') + '.');
  }
  if (st.linked && s.waLink === 'terhubung' && typeof st.waOn === 'boolean' && st.waOn !== s.waOn) {
    // Pengguna membalas STOP/MULAI di WhatsApp: ikuti status server.
    await set({ waOn: st.waOn });
  }
  if (st.linked && st.doneDate === todayKey() && s.doneDate !== st.doneDate) await set({ doneDate: st.doneDate });
  return st;
}

async function pollWaLink() {
  const s = await getAll();
  if (s.waLink !== 'menunggu' || Date.now() - (s.waPairAt || 0) > WA_POLL_LIMIT_MS) {
    chrome.alarms.clear(WA_POLL_ALARM);
    return;
  }
  try {
    await checkWaLink({ notify: true });
  } catch (e) {
    console.warn('Cek status WhatsApp gagal:', e.message);
  }
}

/* ---------------- pesan dari popup & content script ---------------- */

const handlers = {
  async generate(msg) {
    const s = await getAll();
    await set({ draft: { ...s.draft, stage: 'loading', error: '' } });
    try {
      const results = await generateReport({
        apiKey: s.apiKey,
        model: s.model,
        activity: msg.activity,
        belajar: msg.belajar,
        kendala: msg.kendala,
        minChars: CONFIG.MIN_CHARS,
      });
      const cur = (await getAll()).draft;
      await set({ draft: { ...cur, stage: 'hasil', results, resultsId: Date.now(), error: '' } });
      return { results };
    } catch (err) {
      const cur = (await getAll()).draft;
      // Kembali ke form input supaya pesan eror terlihat dan pengguna bisa mencoba lagi.
      const hint = [403, 404, 429].includes(err.status)
        ? ' Buka tab Pengaturan lalu klik Simpan & tes koneksi supaya model lain dipilih otomatis.'
        : '';
      await set({ draft: { ...cur, stage: 'kosong', error: err.message + hint } });
      throw err;
    }
  },

  async testKey(msg) {
    try {
      const r = await testKey({
        apiKey: msg.apiKey,
        model: msg.model,
        onProgress: (p) => set({ keyTestProgress: { ...p, at: Date.now() } }),
      });
      return { model: r.model, models: r.models, attempts: r.attempts };
    } finally {
      await set({ keyTestProgress: null });
    }
  },

  async markDone(msg) {
    await markDone(Boolean(msg.done));
    return {};
  },

  async reportSubmitted(msg) {
    const s = await getAll();
    if (s.doneDate !== todayKey()) {
      await markDone(true);
      // Deteksi dari kalender (msg.silent) tidak perlu notifikasi; deteksi saat klik kirim perlu.
      if (!msg.silent) info('Laporan terkirim', 'Status absen hari ini: Sudah. Pengingat dihentikan sampai besok.');
    }
    return {};
  },

  async waPair() {
    const s = await getAll();
    const data = await callServer('pair', { token: s.serverToken || '', tz: timeZoneId() });
    await set({ serverToken: data.token, waLink: 'menunggu', waCode: data.code, waPairAt: Date.now() });
    chrome.alarms.create(WA_POLL_ALARM, { delayInMinutes: 0.5, periodInMinutes: 0.5 });
    return { waUrl: 'https://wa.me/' + data.botNumber + '?text=' + encodeURIComponent('DAFTAR ' + data.code) };
  },

  async waStatus() {
    return checkWaLink();
  },

  async waTest() {
    const s = await getAll();
    if (!linkedToServer(s)) throw new Error('WhatsApp belum terhubung.');
    await callServer('test', { token: s.serverToken });
    return {};
  },

  async waDelete() {
    const s = await getAll();
    if (s.serverToken) {
      try {
        await callServer('delete', { token: s.serverToken });
      } catch (e) {
        if (e.code !== 'UNKNOWN_TOKEN') throw e;
      }
    }
    await resetWa();
    return {};
  },

  async waCancel() {
    await set({ waLink: 'belum', waCode: '', waPairAt: 0 });
    chrome.alarms.clear(WA_POLL_ALARM);
    return {};
  },
};

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const fn = msg && handlers[msg.type];
  if (!fn) return false;
  fn(msg, sender).then(
    (data) => sendResponse({ ok: true, ...(data || {}) }),
    (err) => sendResponse({ ok: false, error: (err && err.message) || String(err), code: (err && err.code) || '' }),
  );
  return true; // jawab secara asinkron
});
