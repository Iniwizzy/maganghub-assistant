// Content script untuk monev.maganghub.kemnaker.go.id
// Mengisi 3 kolom laporan harian dan mendeteksi laporan yang berhasil dikirim.
//
// Struktur halaman (dicek 13 Nov 2026): Nuxt + Vuetify. Form ada di
// /dashboard/riwayat?date=YYYY-MM-DD&view=edit, berisi:
//   - textarea berlabel "Uraian aktivitas", "Pembelajaran yang diperoleh", "Kendala yang dialami"
//   - v-select "Kehadiran" (bawaan: Hadir), checkbox pernyataan, tombol "Batal" & "Simpan dan Kirim"
//   - kalender: button.calendar-day-button dengan aria-label "Jumat, 13 November 2026, Belum Diisi"
// Semua aturan pencarian ada di SITE supaya mudah disesuaikan bila situsnya berubah.
(() => {
  if (window.__maganghubAssistant) return;
  window.__maganghubAssistant = true;

  const SITE = {
    fields: [
      { key: 'uraian', name: 'Uraian aktivitas', patterns: [/uraian/i, /aktivitas/i, /kegiatan/i] },
      { key: 'pembelajaran', name: 'Pembelajaran', patterns: [/pembelajaran/i, /dipelajari/i, /diperoleh/i] },
      { key: 'kendala', name: 'Kendala', patterns: [/kendala/i, /hambatan/i, /dialami/i] },
    ],
    attendance: /kehadiran/i,
    attendanceOption: /^\s*hadir\s*$/i,
    submitButton: /^(simpan dan kirim|kirim|simpan)\b/i,
    successText: /(berhasil|sukses|terkirim|tersimpan)/i,
    successContainers:
      '[role="alert"], [role="status"], [class*="toast" i], [class*="snack" i], [class*="alert" i], [class*="notif" i], [class*="swal" i]',
    watchSubmitMs: 20000,
    // Kalender riwayat: status hari ini selain "Belum Diisi" berarti tidak perlu diingatkan lagi.
    calendarDay: 'button.calendar-day-button[aria-label]',
    notFilled: /belum diisi/i,
    // "Menunggu Persetujuan" / "Menunggu Tindakan Mentor", "Hadir/Izin disetujui", "Jadwal libur posisi" / "Hari Libur".
    // Sengaja TIDAK termasuk "Tidak Hadir", "Kehadiran Ditolak", "Perlu Tindakan Anda": pengingat tetap jalan.
    doneStatus: /(menunggu|disetujui|izin|libur|sakit)/i,
  };

  const filled = [];
  let watching = false;

  /* ---------------- pencarian kolom ---------------- */

  function isVisible(el) {
    const r = el.getBoundingClientRect();
    const cs = getComputedStyle(el);
    return r.width > 0 && r.height > 0 && cs.visibility !== 'hidden' && cs.display !== 'none';
  }

  function labelText(el) {
    const parts = [];
    if (el.id) {
      const l = document.querySelector('label[for="' + CSS.escape(el.id) + '"]');
      if (l) parts.push(l.textContent);
    }
    const labelledBy = el.getAttribute('aria-labelledby');
    if (labelledBy) {
      labelledBy.split(/\s+/).forEach((id) => {
        const n = document.getElementById(id);
        if (n) parts.push(n.textContent);
      });
    }
    const wrap = el.closest('label');
    if (wrap) parts.push(wrap.textContent);
    return parts.join(' ');
  }

  /** Teks di sekitar kolom, hanya dari pembungkus yang berisi satu kolom saja. */
  function contextText(el, selector) {
    let node = el;
    for (let depth = 0; depth < 4 && node.parentElement; depth++) {
      node = node.parentElement;
      if (node.querySelectorAll(selector).length > 1) break;
      const text = (node.innerText || '').trim();
      if (text) return text.slice(0, 200);
    }
    return '';
  }

  function scoreFor(el, rule) {
    const direct = [el.placeholder, el.getAttribute('aria-label'), el.name, labelText(el)].filter(Boolean).join(' ');
    const context = contextText(el, 'textarea');
    let score = 0;
    rule.patterns.forEach((p, i) => {
      const weight = rule.patterns.length - i;
      if (p.test(direct)) score += 10 * weight;
      else if (p.test(context)) score += 2 * weight;
    });
    return score;
  }

  function findFields() {
    const candidates = Array.from(document.querySelectorAll('textarea')).filter((el) => isVisible(el) && !el.disabled && !el.readOnly);
    const used = new Set();
    const found = {};
    for (const rule of SITE.fields) {
      let best = null;
      let bestScore = 0;
      for (const el of candidates) {
        if (used.has(el)) continue;
        const score = scoreFor(el, rule);
        if (score > bestScore) {
          best = el;
          bestScore = score;
        }
      }
      if (best) {
        found[rule.key] = best;
        used.add(best);
      }
    }
    // Cadangan: tepat 3 textarea tanpa label yang cocok, isi sesuai urutan.
    if (!Object.keys(found).length && candidates.length === 3) {
      SITE.fields.forEach((rule, i) => {
        found[rule.key] = candidates[i];
      });
    }
    return found;
  }

  /** Mengisi nilai lewat setter bawaan supaya React/Vue ikut mendeteksi perubahan. */
  function setNativeValue(el, value) {
    const proto = Object.getPrototypeOf(el);
    const desc = Object.getOwnPropertyDescriptor(proto, 'value');
    el.focus();
    if (desc && desc.set) desc.set.call(el, value);
    else el.value = value;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.blur();
  }

  function setAttendance() {
    const selects = Array.from(document.querySelectorAll('select')).filter(isVisible);
    for (const sel of selects) {
      if (!SITE.attendance.test(labelText(sel) + ' ' + contextText(sel, 'select'))) continue;
      if (sel.value) return 'sudah-terisi';
      const opt = Array.from(sel.options).find((o) => SITE.attendanceOption.test(o.textContent));
      if (!opt) return 'tidak-ada-opsi';
      setNativeValue(sel, opt.value);
      return 'diisi';
    }
    return 'tidak-ditemukan';
  }

  function highlight(el) {
    if (!el.dataset.mhPrevStyle) el.dataset.mhPrevStyle = el.getAttribute('style') || '';
    el.style.outline = '2px solid #1D5FD6';
    el.style.outlineOffset = '1px';
    el.style.background = '#F5F8FF';
  }

  function unhighlight(el) {
    if (el.dataset.mhPrevStyle === undefined) return;
    el.setAttribute('style', el.dataset.mhPrevStyle);
    delete el.dataset.mhPrevStyle;
  }

  function fill(results) {
    const found = findFields();
    const missing = [];
    let count = 0;
    filled.splice(0).forEach(unhighlight);
    SITE.fields.forEach((rule, i) => {
      const el = found[rule.key];
      const value = String(results[i] || '').trim();
      if (!el || !value) {
        missing.push(rule.name);
        return;
      }
      setNativeValue(el, value);
      highlight(el);
      filled.push(el);
      count++;
    });
    const attendance = count ? setAttendance() : 'tidak-diubah';
    if (count) {
      filled[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
      showBanner(missing.length ? 'partial' : 'filled', missing);
    }
    return { filled: count, missing, attendance };
  }

  function clearFilled() {
    filled.splice(0).forEach((el) => {
      setNativeValue(el, '');
      unhighlight(el);
    });
    showBanner('cleared');
  }

  /* ---------------- deteksi laporan terkirim ---------------- */

  document.addEventListener(
    'click',
    (ev) => {
      if (!filled.length) return;
      const btn = ev.target.closest('button, input[type="submit"], [role="button"]');
      if (!btn) return;
      const text = (btn.innerText || btn.value || '').trim();
      if (SITE.submitButton.test(text)) watchForSuccess();
    },
    true,
  );

  function successVisible() {
    return Array.from(document.querySelectorAll(SITE.successContainers)).some(
      (n) => isVisible(n) && SITE.successText.test(n.innerText || ''),
    );
  }

  function watchForSuccess() {
    if (watching) return;
    watching = true;
    const observer = new MutationObserver(() => {
      if (successVisible()) {
        stop();
        onSubmitted();
      }
    });
    const timer = setTimeout(stop, SITE.watchSubmitMs);
    function stop() {
      observer.disconnect();
      clearTimeout(timer);
      watching = false;
    }
    observer.observe(document.body, { childList: true, subtree: true, characterData: true });
  }

  function onSubmitted() {
    filled.splice(0).forEach(unhighlight);
    showBanner('sent');
    reportedToday = true;
    chrome.runtime.sendMessage({ type: 'reportSubmitted' }).catch(() => {});
  }

  /* ---------------- status hari ini dari kalender ---------------- */

  let reportedToday = false;

  function todayLabel() {
    return new Intl.DateTimeFormat('id-ID', { day: 'numeric', month: 'long', year: 'numeric' }).format(new Date());
  }

  /** Status hari ini dari kalender riwayat, mis. "Belum Diisi" / "Menunggu Persetujuan", atau null. */
  function todayStatus() {
    const needle = ', ' + todayLabel() + ', ';
    for (const btn of document.querySelectorAll(SITE.calendarDay)) {
      const label = btn.getAttribute('aria-label') || '';
      const at = label.indexOf(needle);
      if (at >= 0) return label.slice(at + needle.length).trim();
    }
    return null;
  }

  function checkCalendar() {
    if (reportedToday) return;
    const status = todayStatus();
    if (!status || SITE.notFilled.test(status) || !SITE.doneStatus.test(status)) return;
    reportedToday = true;
    chrome.runtime.sendMessage({ type: 'reportSubmitted', silent: true, status }).catch(() => {});
  }

  let calendarTimer = null;
  new MutationObserver(() => {
    clearTimeout(calendarTimer);
    calendarTimer = setTimeout(checkCalendar, 800);
  }).observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['aria-label'] });
  checkCalendar();

  /* ---------------- banner di halaman ---------------- */

  let host = null;

  function showBanner(kind, missing = []) {
    if (!host) {
      host = document.createElement('div');
      host.style.cssText = 'position:fixed;top:16px;right:16px;z-index:2147483647;width:340px;max-width:calc(100vw - 32px);';
      host.attachShadow({ mode: 'open' });
      document.documentElement.append(host);
    }
    const root = host.shadowRoot;
    root.textContent = '';

    const style = document.createElement('style');
    style.textContent = `
      .card { font: 13px/1.45 'Segoe UI', system-ui, sans-serif; color: #111827; background: #fff; border: 2px solid #1D5FD6;
        border-radius: 14px; padding: 12px 14px; box-shadow: 0 8px 24px rgba(15,23,42,.18); display: flex; flex-direction: column; gap: 8px; }
      .card.ok { border-color: #157F3D; background: #E7F5EC; }
      .head { display: flex; align-items: flex-start; gap: 8px; }
      .title { font-weight: 700; flex: 1; }
      .ok .title { color: #136C34; }
      .body { color: #374151; }
      .ok .body { color: #1E4D2E; }
      .actions { display: flex; gap: 8px; flex-wrap: wrap; }
      button { font: inherit; cursor: pointer; }
      .btn { height: 36px; padding: 0 12px; border: 1px solid #8792A4; border-radius: 8px; background: #fff; color: #111827; font-weight: 700; font-size: 12px; }
      .close { width: 28px; height: 28px; border: 0; border-radius: 6px; background: transparent; color: #4B5563; font-size: 18px; line-height: 1; }
      :focus-visible { outline: 2px solid #1D5FD6; outline-offset: 2px; }
    `;
    root.append(style);

    const card = document.createElement('div');
    card.className = 'card' + (kind === 'sent' ? ' ok' : '');
    card.setAttribute('role', 'status');

    const head = document.createElement('div');
    head.className = 'head';
    const title = document.createElement('span');
    title.className = 'title';
    const close = document.createElement('button');
    close.className = 'close';
    close.type = 'button';
    close.setAttribute('aria-label', 'Tutup');
    close.textContent = '×';
    close.addEventListener('click', () => host.remove() || (host = null));
    head.append(title, close);

    const body = document.createElement('span');
    body.className = 'body';
    const actions = document.createElement('div');
    actions.className = 'actions';

    if (kind === 'filled' || kind === 'partial') {
      title.textContent = kind === 'filled' ? 'MagangHub Assistant mengisi 3 kolom' : 'Sebagian kolom sudah diisi';
      body.textContent =
        (kind === 'partial' ? 'Kolom ' + missing.join(', ') + ' tidak ditemukan, salin manual dari popup. ' : '') +
        'Baca ulang dan sesuaikan dengan kegiatanmu yang sebenarnya. Lalu centang pernyataan di bawah form dan klik Simpan dan Kirim.';
      const clear = document.createElement('button');
      clear.type = 'button';
      clear.className = 'btn';
      clear.textContent = 'Kosongkan lagi';
      clear.addEventListener('click', clearFilled);
      actions.append(clear);
    } else if (kind === 'cleared') {
      title.textContent = 'Kolom dikosongkan';
      body.textContent = 'Kamu bisa menulis sendiri atau mengisinya lagi dari popup.';
    } else if (kind === 'sent') {
      title.textContent = 'Laporan terkirim';
      body.textContent = 'Status absen hari ini: Sudah. Pengingat browser dan WhatsApp dihentikan sampai besok.';
      setTimeout(() => {
        if (host) {
          host.remove();
          host = null;
        }
      }, 8000);
    }

    card.append(head, body);
    if (actions.childNodes.length) card.append(actions);
    root.append(card);
  }

  /* ---------------- pesan dari popup ---------------- */

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || msg.type !== 'fill') return false;
    try {
      sendResponse(fill(Array.isArray(msg.results) ? msg.results : []));
    } catch (e) {
      sendResponse({ filled: 0, missing: [], error: e.message });
    }
    return false;
  });
})();
