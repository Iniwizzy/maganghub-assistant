import { CONFIG, formUrl } from '../config.js';
import { getAll, set, DEFAULT_DRAFT, loadingStale } from '../lib/storage.js';
import { activeTimes, isValidTime, nextReminder, todayKey, tzAbbr, DAY_SHORT, DAY_FULL } from '../lib/schedule.js';
import { serverEnabled } from '../lib/server.js';
import { tierOf, bestForTier, groupModels, TIER_DEFAULT } from '../lib/gemini.js';
import { groupModels as groupOrModels, modelLabel, isFree, AUTO_FREE } from '../lib/openrouter.js';

const $ = (id) => document.getElementById(id);
const LABELS = ['Uraian aktivitas', 'Pembelajaran yang diperoleh', 'Kendala yang dialami'];
const ICONS = {
  check: ['M20 6 9 17l-5-5'],
  x: ['M18 6 6 18', 'm6 6 12 12'],
};
const POLL_MS = 3000;
const POLL_LIMIT_MS = 10 * 60 * 1000;
const OR_BUSY_MS = 5 * 60 * 1000; // jendela login OpenRouter dianggap tertinggal setelah 5 menit
const OR_PENDING_MS = 10 * 60 * 1000; // kode login OpenRouter berlaku 10 menit

let s = null; // data tersimpan (chrome.storage.local)
const ui = {
  tab: 'laporan',
  showKey: false,
  adding: false,
  timeError: '',
  lastRemoved: '',
  testState: 'idle', // idle | testing | ok | error
  testMsg: '',
  waMsg: '',
  waOk: false,
  waError: '',
  waDeleted: false,
  confirmDelete: false,
  manualOpen: false,
  renderedModelsKey: '',
  fillMsg: '',
  showOpenSite: false,
  renderedResultsId: undefined,
  loadingAnimated: false,
  pollTimer: null,
  pollStarted: 0,
  orMsg: '',
  orTone: 'muted', // muted | ok | error
  orWorking: false,
  orTesting: false,
  renderedOrModelsKey: '',
};

/* ---------------- helpers ---------------- */

function el(tag, attrs = {}, ...children) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (v === false || v == null) continue;
    node.setAttribute(k, v === true ? '' : String(v));
  }
  for (const c of children) if (c != null) node.append(c);
  return node;
}

function icon(name, size = 14, stroke = 2.5) {
  const ns = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(ns, 'svg');
  const attrs = {
    width: size, height: size, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor',
    'stroke-width': stroke, 'stroke-linecap': 'round', 'stroke-linejoin': 'round', 'aria-hidden': 'true',
  };
  for (const [k, v] of Object.entries(attrs)) svg.setAttribute(k, String(v));
  for (const d of ICONS[name]) {
    const p = document.createElementNS(ns, 'path');
    p.setAttribute('d', d);
    svg.append(p);
  }
  return svg;
}

function debounce(fn, ms) {
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...args), ms);
  };
}

function showText(node, text) {
  node.textContent = text || '';
  node.hidden = !text;
}

function short(text, n) {
  const t = String(text || '').trim();
  return t.length > n ? t.slice(0, n) + '…' : t;
}

async function send(msg) {
  const res = await chrome.runtime.sendMessage(msg);
  if (!res || !res.ok) {
    const err = new Error((res && res.error) || 'Terjadi kesalahan. Coba lagi.');
    err.code = res && res.code;
    throw err;
  }
  return res;
}

async function saveDraft(patch) {
  s.draft = { ...s.draft, ...patch };
  await set({ draft: s.draft });
}

const saveInputsSoon = debounce(() => {
  saveDraft({ activity: $('activity').value, hintBelajar: $('hintBelajar').value, hintKendala: $('hintKendala').value });
}, 400);

const saveResultsSoon = debounce(() => saveDraft({ results: currentResults() }), 400);

function currentResults() {
  return [0, 1, 2].map((i) => {
    const ta = $('res-' + i);
    return ta ? ta.value : '';
  });
}

function isDoneToday() {
  return s.doneDate === todayKey();
}

function waActive() {
  return serverEnabled() && s.waOn && s.waLink === 'terhubung';
}

function useOpenRouter() {
  return s.provider === 'openrouter';
}

/** Penyedia AI yang dipilih sudah siap menulis laporan. */
function providerReady() {
  return useOpenRouter() ? Boolean(s.orKey) : Boolean(s.apiKey);
}

function orBusy() {
  return Boolean(s.orBusy) && Date.now() - s.orBusy < OR_BUSY_MS;
}

function orPending() {
  return Boolean(s.orPending) && Date.now() - s.orPending.at < OR_PENDING_MS;
}

/* ---------------- init ---------------- */

init();

async function init() {
  s = await getAll();
  $('activity').value = s.draft.activity || '';
  $('hintBelajar').value = s.draft.hintBelajar || '';
  $('hintKendala').value = s.draft.hintKendala || '';
  $('apiKey').value = s.apiKey || '';
  $('version').textContent = 'v' + chrome.runtime.getManifest().version;
  $('todayLabel').textContent = new Intl.DateTimeFormat('id-ID', {
    weekday: 'long', day: 'numeric', month: 'short', year: 'numeric',
  }).format(new Date());

  bindEvents();
  render();

  chrome.storage.onChanged.addListener(async (changes, area) => {
    if (area !== 'local') return;
    s = await getAll();
    if (s.waLink !== 'menunggu') stopPolling();
    render();
  });

  // Proses menulis yang mati di tengah jalan (tanpa detak dari background) dikembalikan ke form,
  // saat popup dibuka maupun selama popup terbuka.
  if (loadingStale(s.draft)) await resetStaleLoading();
  setInterval(() => {
    if (loadingStale(s.draft)) resetStaleLoading();
  }, 5000);

  if (s.waLink === 'menunggu' && serverEnabled()) startPolling();
  // Daftar model OpenRouter belum ada (mis. gagal dimuat saat login): muat sekarang di belakang layar.
  if (useOpenRouter() && s.orKey && !(s.orModels && s.orModels.length)) send({ type: 'orModels' }).catch(() => {});
}

/* ---------------- events ---------------- */

function bindEvents() {
  document.querySelectorAll('.tab').forEach((b) =>
    b.addEventListener('click', () => {
      ui.tab = b.dataset.tab;
      render();
    }),
  );

  // Laporan
  $('toggleAbsen').addEventListener('click', () => send({ type: 'markDone', done: !isDoneToday() }).catch(() => {}));
  $('goSettings').addEventListener('click', () => {
    ui.tab = 'pengaturan';
    render();
    (useOpenRouter() ? $('orConnect') : $('apiKey')).focus();
  });
  document.querySelectorAll('[data-mode]').forEach((b) =>
    b.addEventListener('click', () => saveDraft({ mode: b.dataset.mode })),
  );
  ['activity', 'hintBelajar', 'hintKendala'].forEach((id) =>
    $(id).addEventListener('input', () => {
      if (s.draft.error) saveDraft({ error: '' });
      saveInputsSoon();
    }),
  );
  $('generate').addEventListener('click', generate);
  $('regenerate').addEventListener('click', generate);
  // Batal: kembali ke form; jawaban yang datang belakangan dibuang oleh background (genId tidak cocok).
  $('cancelGen').addEventListener('click', () => saveDraft({ stage: 'kosong', genId: null, error: '' }));
  $('fill').addEventListener('click', fill);
  $('openSite').addEventListener('click', () => chrome.tabs.create({ url: formUrl(todayKey()) }));
  $('newReport').addEventListener('click', newReport);
  $('backToResult').addEventListener('click', () => saveDraft({ stage: 'hasil' }));

  // Pengingat
  $('notifSwitch').addEventListener('click', () => set({ notifOn: !s.notifOn }));
  $('undoBtn').addEventListener('click', undoRemove);
  $('confirmAdd').addEventListener('click', confirmAdd);
  $('cancelAdd').addEventListener('click', () => {
    ui.adding = false;
    ui.timeError = '';
    render();
  });
  $('newTime').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') confirmAdd();
  });
  $('newTime').addEventListener('input', () => {
    if (ui.timeError) {
      ui.timeError = '';
      render();
    }
  });

  $('waSwitch').addEventListener('click', () => set({ waOn: !s.waOn }));
  $('connectWa').addEventListener('click', connectWa);
  $('reopenWa').addEventListener('click', connectWa);
  $('cancelWa').addEventListener('click', () => {
    stopPolling();
    send({ type: 'waCancel' }).catch(() => {});
  });
  $('testWa').addEventListener('click', testWa);
  $('disconnectWa').addEventListener('click', disconnectWa);

  // Pengaturan
  $('toggleKey').addEventListener('click', () => {
    ui.showKey = !ui.showKey;
    render();
  });
  $('saveKey').addEventListener('click', () => saveKey());
  document.querySelectorAll('[data-tier]').forEach((b) => b.addEventListener('click', () => chooseTier(b.dataset.tier)));
  $('toggleManual').addEventListener('click', () => {
    ui.manualOpen = !ui.manualOpen;
    render();
  });
  $('model').addEventListener('change', () => chooseManual($('model').value));

  // Penyedia AI & OpenRouter
  document.querySelectorAll('[data-provider]').forEach((b) => b.addEventListener('click', () => chooseProvider(b.dataset.provider)));
  $('orConnect').addEventListener('click', orConnect);
  $('orManualStart').addEventListener('click', orManualStart);
  $('orManualFinish').addEventListener('click', orManualFinish);
  $('orCode').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') orManualFinish();
  });
  $('orManualCancel').addEventListener('click', () => {
    setOrMsg('');
    send({ type: 'orManualCancel' }).catch(() => {});
  });
  $('orModel').addEventListener('change', () => {
    // Baca pilihan dulu: render ulang sebelum tersimpan akan mengembalikan dropdown ke model lama.
    const model = $('orModel').value;
    ui.orMsg = '';
    set({ orModel: model });
  });
  $('orTest').addEventListener('click', orTest);
  $('orRefresh').addEventListener('click', orRefresh);
  $('orDisconnect').addEventListener('click', () => {
    setOrMsg('');
    send({ type: 'orDisconnect' }).catch((e) => setOrMsg(e.message, 'error'));
  });
}

/* ---------------- laporan ---------------- */

async function generate() {
  const activity = $('activity').value.trim();
  if (!providerReady()) {
    ui.tab = 'pengaturan';
    render();
    return;
  }
  if (activity.length < 5) {
    await saveDraft({ error: 'Tulis dulu 1 kalimat tentang kegiatanmu hari ini.' });
    $('activity').focus();
    return;
  }
  const detail = s.draft.mode === 'detail';
  ui.fillMsg = '';
  ui.showOpenSite = false;
  await saveDraft({
    activity,
    hintBelajar: $('hintBelajar').value,
    hintKendala: $('hintKendala').value,
    error: '',
  });
  // Background yang menyimpan hasil/eror ke storage; popup cukup mengikuti perubahan storage.
  send({
    type: 'generate',
    activity,
    belajar: detail ? $('hintBelajar').value.trim() : '',
    kendala: detail ? $('hintKendala').value.trim() : '',
  }).catch(() => {});
}

async function resetStaleLoading() {
  await saveDraft({
    stage: 'kosong',
    genId: null,
    error: 'Pembuatan laporan sebelumnya terhenti (browser ditutup, laptop tidur, atau extension dimuat ulang). Klik Buat laporan dengan AI lagi.',
  });
}

async function fill() {
  ui.fillMsg = '';
  ui.showOpenSite = false;
  const results = currentResults();
  saveDraft({ results });

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.url || !tab.url.startsWith(CONFIG.SITE_ORIGIN)) {
    ui.fillMsg = 'Buka halaman Tambah Laporan di monev.maganghub dulu, lalu klik lagi.';
    ui.showOpenSite = true;
    render();
    return;
  }

  let res;
  try {
    res = await chrome.tabs.sendMessage(tab.id, { type: 'fill', results });
  } catch (e) {
    ui.fillMsg = 'Halaman MagangHub perlu dimuat ulang dulu (tekan F5), lalu klik lagi.';
    render();
    return;
  }

  if (!res || !res.filled) {
    ui.fillMsg = 'Kolom laporan tidak ditemukan di halaman ini. Buka form laporan hari ini dulu, atau pakai tombol Salin.';
    ui.showOpenSite = true;
    render();
    return;
  }
  if (res.missing && res.missing.length) {
    ui.fillMsg = 'Sebagian sudah terisi. Kolom ' + res.missing.join(', ') + ' tidak ditemukan, salin manual dengan tombol Salin.';
    render();
    return;
  }
  await saveDraft({ stage: 'terisi' });
}

async function newReport() {
  $('activity').value = '';
  $('hintBelajar').value = '';
  $('hintKendala').value = '';
  ui.renderedResultsId = undefined;
  ui.fillMsg = '';
  ui.showOpenSite = false;
  await saveDraft({ ...DEFAULT_DRAFT, mode: s.draft.mode });
  $('activity').focus();
}

function renderResults(results) {
  const box = $('results');
  box.textContent = '';
  results.forEach((text, i) => {
    const copy = el('button', { type: 'button', class: 'link-btn' }, 'Salin');
    const ta = el('textarea', { id: 'res-' + i, rows: '5', class: 'field' });
    ta.value = text || '';
    const count = el('span', { id: 'count-' + i, class: 'count', 'aria-live': 'polite' });
    box.append(
      el(
        'div',
        { class: 'card result' },
        el('div', { class: 'result-head' }, el('label', { for: 'res-' + i, class: 'result-label' }, LABELS[i]), copy),
        ta,
        count,
      ),
    );
    ta.addEventListener('input', () => {
      updateCount(i);
      saveResultsSoon();
    });
    copy.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(ta.value);
        copy.textContent = 'Tersalin';
      } catch (e) {
        ta.select();
        copy.textContent = 'Tekan Ctrl+C';
      }
      setTimeout(() => (copy.textContent = 'Salin'), 1600);
    });
    updateCount(i);
  });
}

function updateCount(i) {
  const n = $('res-' + i).value.trim().length;
  const ok = n >= CONFIG.MIN_CHARS;
  const c = $('count-' + i);
  c.className = 'count ' + (ok ? 'ok' : 'bad');
  c.textContent = '';
  if (ok) c.append(icon('check', 14, 2.5));
  c.append(
    el('span', {}, n + ' karakter · ' + (ok ? 'memenuhi minimal ' + CONFIG.MIN_CHARS : 'kurang ' + (CONFIG.MIN_CHARS - n) + ' lagi')),
  );
}

function animateProgress() {
  if (ui.loadingAnimated) return;
  ui.loadingAnimated = true;
  const bar = $('progressBar');
  bar.style.transition = 'none';
  bar.style.width = '4%';
  requestAnimationFrame(() =>
    requestAnimationFrame(() => {
      bar.style.transition = '';
      bar.style.width = '92%';
    }),
  );
}

/* ---------------- pengingat ---------------- */

function openAdd() {
  ui.adding = true;
  ui.lastRemoved = '';
  ui.timeError = '';
  $('newTime').value = '';
  render();
  $('newTime').focus();
}

function confirmAdd() {
  const t = ($('newTime').value || '').slice(0, 5);
  if (!isValidTime(t)) return setTimeError('Pilih jamnya dulu.');

  const di = s.defaultTimes.findIndex((d) => d.t === t);
  if (di >= 0) {
    ui.adding = false;
    ui.timeError = '';
    set({ defaultTimes: s.defaultTimes.map((d, j) => (j === di ? { ...d, on: true } : d)) });
    render();
    return;
  }
  if (s.customTimes.includes(t)) return setTimeError('Jam ' + t + ' sudah ada.');
  if (s.customTimes.length >= CONFIG.MAX_CUSTOM_TIMES) {
    return setTimeError('Maksimal ' + CONFIG.MAX_CUSTOM_TIMES + ' jam tambahan.');
  }
  ui.adding = false;
  ui.timeError = '';
  set({ customTimes: s.customTimes.concat([t]).sort() });
  render();
}

function setTimeError(msg) {
  ui.timeError = msg;
  render();
}

function undoRemove() {
  const t = ui.lastRemoved;
  ui.lastRemoved = '';
  if (t && !s.customTimes.includes(t) && s.customTimes.length < CONFIG.MAX_CUSTOM_TIMES) {
    set({ customTimes: s.customTimes.concat([t]).sort() });
  }
  render();
}

async function connectWa() {
  ui.waError = '';
  ui.waDeleted = false;
  render();
  try {
    const res = await send({ type: 'waPair' });
    startPolling();
    // Membuka tab baru akan menutup popup; background tetap memeriksa status.
    chrome.tabs.create({ url: res.waUrl });
  } catch (e) {
    ui.waError = e.message;
    render();
  }
}

function startPolling() {
  stopPolling();
  ui.pollStarted = Date.now();
  ui.pollTimer = setInterval(async () => {
    if (Date.now() - ui.pollStarted > POLL_LIMIT_MS) return stopPolling();
    try {
      await send({ type: 'waStatus' });
    } catch (e) {
      // Diam saja; coba lagi pada putaran berikutnya.
    }
  }, POLL_MS);
}

function stopPolling() {
  if (ui.pollTimer) clearInterval(ui.pollTimer);
  ui.pollTimer = null;
}

async function testWa() {
  ui.waMsg = 'Mengirim pesan uji…';
  ui.waOk = false;
  ui.waError = '';
  render();
  try {
    await send({ type: 'waTest' });
    ui.waMsg = 'Terkirim. Cek WhatsApp-mu.';
    ui.waOk = true;
  } catch (e) {
    ui.waMsg = '';
    ui.waError = e.message;
  }
  render();
}

async function disconnectWa() {
  if (!ui.confirmDelete) {
    ui.confirmDelete = true;
    render();
    setTimeout(() => {
      ui.confirmDelete = false;
      render();
    }, 4000);
    return;
  }
  ui.confirmDelete = false;
  ui.waError = '';
  try {
    await send({ type: 'waDelete' });
    ui.waDeleted = true;
    ui.waMsg = '';
  } catch (e) {
    ui.waError = e.message;
  }
  render();
}

/* ---------------- pengaturan ---------------- */

const TIER_INFO = {
  cepat: 'Jawaban dalam beberapa detik, cocok untuk laporan harian.',
  hemat: 'Paling irit kuota gratis. Tulisannya sedikit lebih sederhana.',
  terbaik: 'Tulisan paling rapi, tapi lebih lambat dan kuota gratisnya kecil.',
  manual: 'Model dipilih manual.',
};

function currentTier() {
  return s.modelTier === 'manual' ? 'manual' : tierOf(s.model || CONFIG.DEFAULT_MODEL);
}

/** Klik Cepat/Hemat/Terbaik: pilih model terbaik di kelompok itu, lalu tes bila key sudah ada. */
async function chooseTier(tier) {
  const model = bestForTier(s.availableModels, tier);
  if (ui.testState === 'testing') return;
  if ($('apiKey').value.trim() || s.apiKey) {
    await saveKey(model, tier);
  } else {
    await set({ model, modelTier: tier });
  }
}

async function chooseManual(model) {
  if ($('apiKey').value.trim() || s.apiKey) await saveKey(model, 'manual');
  else await set({ model, modelTier: 'manual' });
}

async function saveKey(modelOverride, tierOverride) {
  const apiKey = $('apiKey').value.trim() || s.apiKey;
  const tier = typeof tierOverride === 'string' ? tierOverride : currentTier();
  // Tanpa pilihan khusus: pakai versi terbaik di kelompok yang aktif (bila daftar model sudah diketahui).
  const model =
    typeof modelOverride === 'string'
      ? modelOverride
      : tier !== 'manual' && s.availableModels && s.availableModels.length
        ? bestForTier(s.availableModels, tier)
        : s.model || CONFIG.DEFAULT_MODEL;
  if (!apiKey) {
    ui.testState = 'error';
    ui.testMsg = 'Isi API key dulu.';
    render();
    return;
  }
  ui.testState = 'testing';
  ui.testMsg = 'Mengecek model yang tersedia untuk key ini…';
  ui.testStarted = Date.now();
  const ticker = setInterval(() => {
    ui.testMsg = progressText();
    render();
  }, 1000);
  render();
  try {
    const res = await send({ type: 'testKey', apiKey, model });
    const switched = res.model !== model;
    await set({
      apiKey,
      model: res.model,
      modelTier: switched ? tierOf(res.model) : tier,
      keyStatus: 'ok',
      availableModels: res.models || [],
    });
    ui.testState = 'ok';
    ui.testMsg =
      'Terhubung ke Gemini. Key tersimpan di browser ini.' +
      (switched
        ? ' ' + model + ' tidak bisa dipakai sekarang (' + ((res.attempts || [])[0] || '-').replace(/^[^:]+:\s*/, '') + '), jadi dipakai ' + res.model + '.'
        : '');
  } catch (e) {
    ui.testState = 'error';
    ui.testMsg = e.message;
  } finally {
    clearInterval(ticker);
  }
  render();
}

function progressText() {
  const p = s.keyTestProgress;
  const secs = Math.round((Date.now() - (p && p.at ? p.at : ui.testStarted)) / 1000);
  if (p && p.step === 'try') {
    return 'Mencoba model ' + p.model + ' (' + p.index + '/' + p.total + ')… ' + secs + ' dtk';
  }
  return 'Mengambil daftar model untuk key ini… ' + secs + ' dtk';
}

/** Dropdown manual: dikelompokkan (Flash / Flash-Lite / Pro / Lainnya), dibangun ulang hanya bila daftar berubah. */
function renderManualSelect() {
  const select = $('model');
  const models = s.availableModels && s.availableModels.length ? s.availableModels : Object.values(TIER_DEFAULT);
  const key = models.join('|');
  if (ui.renderedModelsKey !== key) {
    select.textContent = '';
    groupModels(models).forEach((g) => {
      const group = el('optgroup', { label: g.label });
      g.models.forEach((m) => group.append(el('option', { value: m.id }, m.note ? m.id + ' · ' + m.note : m.id)));
      select.append(group);
    });
    ui.renderedModelsKey = key;
  }
  if (s.model && ![...select.options].some((o) => o.value === s.model)) {
    select.append(el('option', { value: s.model }, s.model));
  }
  if (document.activeElement !== select) select.value = s.model || CONFIG.DEFAULT_MODEL;
}

function renderModelPicker() {
  const tier = currentTier();
  const busy = ui.testState === 'testing';
  document.querySelectorAll('[data-tier]').forEach((b) => {
    const on = b.dataset.tier === tier;
    b.classList.toggle('active', on);
    b.setAttribute('aria-pressed', String(on));
    b.disabled = busy;
  });
  $('modelInfo').textContent = TIER_INFO[tier] + ' Memakai ' + (s.model || CONFIG.DEFAULT_MODEL) + '.';
  $('manualBox').hidden = !ui.manualOpen;
  $('toggleManual').setAttribute('aria-expanded', String(ui.manualOpen));
  $('toggleManual').textContent = ui.manualOpen ? 'Sembunyikan pilihan manual' : 'Pilih model manual';
  $('model').disabled = busy;
  renderManualSelect();
}

/* ---------------- OpenRouter ---------------- */

function setOrMsg(text, tone = 'muted') {
  ui.orMsg = text;
  ui.orTone = tone;
  render();
}

async function chooseProvider(provider) {
  if (s.provider === provider) return;
  ui.orMsg = '';
  await set({ provider });
  if (provider === 'openrouter' && s.orKey && !(s.orModels && s.orModels.length)) send({ type: 'orModels' }).catch(() => {});
}

/** Jendela login dibuka oleh background; popup ini biasanya tertutup begitu jendela itu muncul. */
function orConnect() {
  setOrMsg('');
  send({ type: 'orConnect' }).catch((e) => setOrMsg(e.message, 'error'));
}

async function orManualStart() {
  setOrMsg('');
  try {
    const res = await send({ type: 'orManualStart' });
    // Tab baru menutup popup; saat dibuka lagi, kotak kode tetap tampil selama 10 menit.
    chrome.tabs.create({ url: res.url });
  } catch (e) {
    setOrMsg(e.message, 'error');
  }
}

async function orManualFinish() {
  const code = $('orCode').value.trim();
  if (!code) return setOrMsg('Tempel kode dari OpenRouter dulu.', 'error');
  ui.orWorking = true;
  setOrMsg('Menghubungkan…');
  try {
    await send({ type: 'orManualFinish', code });
    $('orCode').value = '';
    ui.orWorking = false;
    setOrMsg('Terhubung ke OpenRouter. Key tersimpan di browser ini.', 'ok');
  } catch (e) {
    ui.orWorking = false;
    setOrMsg(e.message, 'error');
  }
}

async function orTest() {
  ui.orTesting = true;
  setOrMsg('Mengetes model…');
  try {
    const r = await send({ type: 'orTest' });
    const picked = s.orModel || AUTO_FREE;
    let msg = r.model === picked ? 'Model menjawab, siap dipakai.' : picked + ' sedang penuh, jadi cadangannya (' + r.model + ') yang menjawab. Cadangan ini dipakai otomatis bila perlu.';
    if (r.answeredBy && r.answeredBy !== r.model) msg += ' Dijawab oleh ' + r.answeredBy + '.';
    ui.orTesting = false;
    setOrMsg(msg, 'ok');
  } catch (e) {
    ui.orTesting = false;
    setOrMsg(e.message, 'error');
  }
}

async function orRefresh() {
  setOrMsg('Memuat daftar model…');
  try {
    const r = await send({ type: 'orModels' });
    setOrMsg('Daftar model diperbarui (' + r.count + ' model).', 'ok');
  } catch (e) {
    setOrMsg(e.message, 'error');
  }
}

/** Dropdown model OpenRouter: gratis dulu, lalu berbayar; dibangun ulang hanya bila daftar berubah. */
function renderOrSelect() {
  const select = $('orModel');
  const models = s.orModels && s.orModels.length ? s.orModels : [];
  const key = models.length + '|' + (models[0] ? models[0].id : '') + '|' + (models.length ? models[models.length - 1].id : '');
  if (ui.renderedOrModelsKey !== key) {
    select.textContent = '';
    groupOrModels(models).forEach((g) => {
      const group = el('optgroup', { label: g.label });
      g.models.forEach((m) => group.append(el('option', { value: m.id }, modelLabel(m))));
      select.append(group);
    });
    ui.renderedOrModelsKey = key;
  }
  const model = s.orModel || AUTO_FREE;
  if (![...select.options].some((o) => o.value === model)) select.append(el('option', { value: model }, model));
  if (document.activeElement !== select) select.value = model;

  $('orModelInfo').textContent =
    model === AUTO_FREE
      ? 'Gratis. OpenRouter memilih model gratis yang sedang tersedia. Batasnya 50 permintaan per hari tanpa saldo.'
      : isFree(model, s.orModels)
        ? 'Gratis, tanpa saldo, batas 50 permintaan per hari. Bila sedang penuh, model gratis lain dipakai otomatis.'
        : 'Berbayar: tiap laporan memotong saldo OpenRouter-mu.';
}

function renderOr() {
  const linked = Boolean(s.orKey);
  const busy = orBusy();
  const pending = orPending();
  $('orOk').hidden = !linked;
  $('orBelum').hidden = linked;
  $('orTerhubung').hidden = !linked;

  $('orConnect').disabled = busy;
  $('orConnect').textContent = busy ? 'Menunggu login di jendela OpenRouter…' : 'Hubungkan OpenRouter';
  $('orManualStart').hidden = pending;
  $('orManualBox').hidden = !pending;
  $('orManualFinish').disabled = ui.orWorking;
  $('orTest').disabled = ui.orTesting;
  $('orTest').textContent = ui.orTesting ? 'Mengetes…' : 'Tes model ini';
  if (linked) renderOrSelect();

  const msg = ui.orMsg || s.orError || '';
  const tone = ui.orMsg ? ui.orTone : 'error';
  const node = $('orMsg');
  showText(node, msg);
  node.className = 'small strong ' + (tone === 'ok' ? 'ok-text' : tone === 'error' ? 'error-text' : 'muted');
}

/* ---------------- render ---------------- */

function render() {
  renderHeader();
  renderTabs();
  renderLaporan();
  renderPengingat();
  renderPengaturan();
}

function renderHeader() {
  let ok;
  let label;
  if (useOpenRouter()) {
    ok = Boolean(s.orKey);
    label = ok ? 'OpenRouter terhubung' : 'OpenRouter belum terhubung';
  } else {
    ok = Boolean(s.apiKey) && s.keyStatus === 'ok';
    label = ok ? 'Gemini terhubung' : s.apiKey ? 'Gemini belum dites' : 'Gemini belum diatur';
  }
  $('geminiDot').className = 'dot' + (ok ? ' dot-on' : '');
  $('geminiLabel').textContent = label;
}

function renderTabs() {
  document.querySelectorAll('.tab').forEach((b) => {
    const on = b.dataset.tab === ui.tab;
    b.classList.toggle('active', on);
    b.setAttribute('aria-pressed', String(on));
  });
  ['laporan', 'pengingat', 'pengaturan'].forEach((t) => {
    $('tab-' + t).hidden = t !== ui.tab;
  });
}

function nextLabelText() {
  if (isDoneToday()) return 'Laporan beres. Pengingat hari ini dihentikan.';
  const wa = waActive();
  if (!s.notifOn && !wa) return 'Semua pengingat mati. Nyalakan di tab Pengingat.';
  const next = nextReminder(activeTimes(s.defaultTimes, s.customTimes), s.days, new Date());
  if (!next) return 'Tidak ada pengingat lagi hari ini.';
  const via = s.notifOn && wa ? 'browser & WhatsApp' : s.notifOn ? 'notifikasi browser' : 'WhatsApp';
  return 'Pengingat berikutnya ' + next + ' ' + tzAbbr() + ' lewat ' + via + '.';
}

function renderLaporan() {
  const done = isDoneToday();
  const pill = $('absenPill');
  pill.textContent = done ? 'Sudah absen' : 'Belum absen';
  pill.className = 'pill ' + (done ? 'pill-ok' : 'pill-warn');
  $('toggleAbsen').textContent = done ? 'Batalkan tanda sudah absen' : 'Tandai sudah absen';
  $('nextLabel').textContent = nextLabelText();
  $('needKey').hidden = providerReady();
  if (useOpenRouter()) {
    $('needKeyTitle').textContent = 'Hubungkan OpenRouter dulu';
    $('needKeyBody').textContent = 'Login sekali di tab Pengaturan. Tanpa itu AI belum bisa menulis laporan.';
    $('goSettings').textContent = 'Hubungkan sekarang';
  } else {
    $('needKeyTitle').textContent = 'Atur Gemini API key dulu';
    $('needKeyBody').textContent = 'Gratis dari Google AI Studio. Tanpa key ini AI belum bisa menulis laporan.';
    $('goSettings').textContent = 'Atur sekarang';
  }

  const d = s.draft;
  const stage = d.stage || 'kosong';
  ['kosong', 'loading', 'hasil', 'terisi'].forEach((k) => {
    $('stage-' + k).hidden = k !== stage;
  });

  document.querySelectorAll('[data-mode]').forEach((b) => {
    const on = b.dataset.mode === (d.mode || 'cepat');
    b.classList.toggle('active', on);
    b.setAttribute('aria-pressed', String(on));
  });
  $('detailFields').hidden = d.mode !== 'detail';
  showText($('genError'), d.error);

  if (stage === 'loading') {
    $('loadingTitle').textContent = useOpenRouter() ? 'AI sedang menulis 3 kolom lewat OpenRouter…' : 'Gemini sedang menulis 3 kolom…';
    $('loadingFrom').textContent = 'Dari: “' + short(d.activity, 60) + '”';
    animateProgress();
  } else {
    ui.loadingAnimated = false;
  }

  if (stage === 'hasil' && Array.isArray(d.results) && ui.renderedResultsId !== d.resultsId) {
    renderResults(d.results);
    ui.renderedResultsId = d.resultsId;
  }
  showText($('fillError'), ui.fillMsg);
  $('openSite').hidden = !ui.showOpenSite;
}

function renderPengingat() {
  $('notifSwitch').setAttribute('aria-checked', String(Boolean(s.notifOn)));
  $('notifBody').classList.toggle('dim', !s.notifOn && !waActive());
  $('tzLabel').textContent = tzAbbr();
  $('tzLabel2').textContent = tzAbbr();
  renderChips();
  renderDays();

  $('undoBar').hidden = !ui.lastRemoved;
  $('undoText').textContent = 'Jam ' + ui.lastRemoved + ' dihapus';
  $('addForm').hidden = !ui.adding;
  showText($('timeError'), ui.timeError);

  renderWa();
}

function keepFocus(box, build) {
  const active = document.activeElement;
  const key = active && box.contains(active) ? active.dataset.key : null;
  box.textContent = '';
  build();
  if (key) {
    const again = box.querySelector('[data-key="' + key + '"]');
    if (again) again.focus();
  }
}

function renderChips() {
  const box = $('chips');
  keepFocus(box, () => {
    s.defaultTimes.forEach((d, i) => {
      const b = el(
        'button',
        { type: 'button', class: 'chip-toggle' + (d.on ? ' on' : ''), 'aria-pressed': String(Boolean(d.on)), 'data-key': 'def-' + d.t },
        d.on ? icon('check', 14, 3) : el('span', { class: 'box', 'aria-hidden': 'true' }),
        el('span', {}, d.t),
      );
      b.addEventListener('click', () =>
        set({ defaultTimes: s.defaultTimes.map((x, j) => (j === i ? { ...x, on: !x.on } : x)) }),
      );
      box.append(b);
    });

    s.customTimes
      .slice()
      .sort()
      .forEach((t) => {
        const del = el('button', { type: 'button', 'aria-label': 'Hapus jam ' + t, title: 'Hapus jam ini', 'data-key': 'del-' + t }, icon('x'));
        del.addEventListener('click', () => {
          ui.lastRemoved = t;
          set({ customTimes: s.customTimes.filter((x) => x !== t) });
        });
        box.append(el('span', { class: 'chip' }, el('span', {}, t), del));
      });

    if (!activeTimes(s.defaultTimes, s.customTimes).length) {
      box.append(el('span', { class: 'error inline' }, 'Belum ada jam pengingat'));
    }
    if (!ui.adding) {
      if (s.customTimes.length < CONFIG.MAX_CUSTOM_TIMES) {
        const add = el('button', { type: 'button', class: 'chip-add', 'data-key': 'add' }, '+ Tambah jam');
        add.addEventListener('click', openAdd);
        box.append(add);
      } else {
        box.append(el('span', { class: 'muted small inline' }, 'Maksimal ' + CONFIG.MAX_CUSTOM_TIMES + ' jam tambahan'));
      }
    }
  });
}

function renderDays() {
  const box = $('days');
  keepFocus(box, () => {
    DAY_SHORT.forEach((label, i) => {
      const on = Boolean(s.days[i]);
      const b = el(
        'button',
        { type: 'button', class: 'day' + (on ? ' on' : ''), 'aria-pressed': String(on), 'aria-label': DAY_FULL[i], 'data-key': 'day-' + i },
        label,
      );
      b.addEventListener('click', () => set({ days: s.days.map((x, j) => (j === i ? !x : x)) }));
      box.append(b);
    });
  });
}

function renderWa() {
  const enabled = serverEnabled();
  const link = enabled ? s.waLink : 'off';
  $('waUnavailable').hidden = enabled;
  $('waBelum').hidden = link !== 'belum';
  $('waMenunggu').hidden = link !== 'menunggu';
  $('waTerhubung').hidden = link !== 'terhubung';
  $('waSwitch').hidden = link !== 'terhubung';
  $('waSwitch').setAttribute('aria-checked', String(Boolean(s.waOn)));
  $('waTerhubung').classList.toggle('dim', !s.waOn);

  $('waCode').textContent = 'DAFTAR ' + (s.waCode || '····');
  $('waNumber').textContent = s.waPhone || 'nomormu';
  $('waDeleted').hidden = !ui.waDeleted;
  const msg = $('waMsg');
  msg.textContent = ui.waMsg;
  msg.className = 'small strong ' + (ui.waOk ? 'ok-text' : 'muted');
  $('disconnectWa').textContent = ui.confirmDelete
    ? 'Yakin? Klik sekali lagi untuk menghapus'
    : 'Putuskan dan hapus nomor dari server';
  showText($('waError'), ui.waError);
}

function renderPengaturan() {
  const provider = useOpenRouter() ? 'openrouter' : 'gemini';
  document.querySelectorAll('[data-provider]').forEach((b) => {
    const on = b.dataset.provider === provider;
    b.classList.toggle('active', on);
    b.setAttribute('aria-pressed', String(on));
  });
  $('geminiCard').hidden = provider !== 'gemini';
  $('orCard').hidden = provider !== 'openrouter';
  renderOr();

  $('keyOk').hidden = !(s.apiKey && s.keyStatus === 'ok');
  renderModelPicker();
  $('apiKey').type = ui.showKey ? 'text' : 'password';
  $('toggleKey').setAttribute('aria-label', ui.showKey ? 'Sembunyikan API key' : 'Tampilkan API key');
  $('saveKey').disabled = ui.testState === 'testing';
  $('saveKey').textContent = ui.testState === 'testing' ? 'Menguji koneksi…' : 'Simpan & tes koneksi';

  const tm = $('testMsg');
  showText(tm, ui.testMsg);
  tm.className = 'small strong ' + (ui.testState === 'ok' ? 'ok-text' : ui.testState === 'error' ? 'error-text' : 'muted');

  const privacy = $('privacyLink');
  privacy.hidden = !CONFIG.PRIVACY_URL;
  if (CONFIG.PRIVACY_URL) privacy.href = CONFIG.PRIVACY_URL;
}
